#include <iostream>
using std::cout; using std::endl;

#include "Banco/Banco.h"
#include "Pessoa/PessoaJuridica.h"
#include "Pessoa/PessoaFisica.h"
#include "Conta/ContaComum.h"
#include "Conta/ContaLimite.h"
#include "Conta/ContaPoupanca.h"

using namespace std;

int main() {
  
  return 0;
}