#include "Imovel.h"

#include <iostream>
#include <string>

using namespace std;

Imovel::Imovel(string endereco, float preco) : endereco(endereco), preco(preco) {};

