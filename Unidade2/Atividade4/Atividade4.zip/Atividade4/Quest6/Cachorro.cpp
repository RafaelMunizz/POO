#include "Cachorro.h"

#include <iostream>
#include <string>

using namespace std;

Cachorro::Cachorro(string nome, string raca) : Animal(nome, raca) {}
