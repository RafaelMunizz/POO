#include "Gato.h"

#include <iostream>
#include <string>

using namespace std;

Gato::Gato(string nome, string raca) : Animal(nome, raca) {}
