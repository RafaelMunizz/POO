#include "Animal.h"

#include <iostream>
#include <string>

using namespace std;

Animal::Animal(string nome, string raca) : nome(nome), raca(raca) {}

