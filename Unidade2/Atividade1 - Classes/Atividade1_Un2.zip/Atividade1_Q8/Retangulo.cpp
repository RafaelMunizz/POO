#include <iostream>
#include "Retangulo.h"

using namespace std;

Retangulo::Retangulo(float pAltura = 1.0, float pLargura = 1.0) {

    setAltura(pAltura);
    setLargura(pLargura);
}
